A work in progress add-on that allows you to search the web quickly for the highlighted text on a web page with the key combo CTRL+s. Allows for a user to select between Google, DuckDuckGo, and Bing.
